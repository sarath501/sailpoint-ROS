package com.sail;
import sailpoint.api.SailPointContext;
import java.text.SimpleDateFormat;
import sailpoint.object.AuditEvent;
import sailpoint.api.SailPointFactory;
import sailpoint.connector.ExpiredPasswordException;
import sailpoint.object.Identity;
import sailpoint.object.IdentitySelector;
import sailpoint.object.IdentityTrigger;
import sailpoint.object.QueryOptions;
import sailpoint.object.Rule;
import sailpoint.spring.SpringStarter;
import sailpoint.tools.GeneralException;
import sailpoint.object.ProvisioningPlan.AttributeRequest;
import org.apache.log4j.*;
import java.util.*;

import javax.lang.model.element.ModuleElement.Directive;
import javax.script.ScriptContext;

import sailpoint.object.ProvisioningPlan;
import sailpoint.object.ProvisioningPlan.AccountRequest;

public class Plan {
	public static ScriptContext context;
	public static void main(String[] args) {
		inactive();
	}
		
		 private static void inactive() {
		
		
	}

		private static void ProvisioningPlan() {
		
			 SpringStarter starter = new SpringStarter("iiqBeans"); 
			  starter.start();
			Active plan = new Active(); 
		 SailPointContext context;
		 boolean inactive=true;
			boolean deactivate = inactive;
		try {
			context = SailPointFactory.createContext();
		
		 Identity identityObject = context.getObjectByName(Identity.class,"sarath");
		 AccountRequest acctReq = new AccountRequest();
		 List accreqs= new ArrayList();
		 
		starter.close();
		 if(deactivate){
		 

		   System.out.println(" InActivation is :"+ identityObject.isInactive());
		  acctReq.setOperation(AccountRequest.Operation.Disable);
		  acctReq.setApplication("ROS_APP");
		  acctReq.add(new AttributeRequest("inactive",inactive)); 
		  identityObject.setInactive(inactive);
		  System.out.println(" InActivation is :"+ identityObject.isInactive());
		 }
		 else{
		 acctReq.setOperation(AccountRequest.Operation.Enable);
		 acctReq.setApplication("ROS_APP");
		 acctReq.add(new AttributeRequest("inactive",inactive)); 

		 }
		  
		 
		 acctReq.setNativeIdentity("sarath");
		 accreqs.add(acctReq);
		 plan.setAccountRequests(accreqs);
		 plan.setIdentity(identityObject);
		 //log.debug("Plan = " + plan.toXml());
		 
		//else {
		// log.debug("Subscription Exceeded"); 
		// }
		//System.out.println(plan);
		 //return plan;
		} catch (GeneralException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

		}

