package com.sail;

import java.sql.SQLException;
import java.util.HashSet;
import java.util.Map;

import sailpoint.tools.GeneralException;;
public class Example {
public static void main(String[] args) throws GeneralException, SQLException {
//	SailPointContext context = null;
//	Connection jdbcconnection = context.getJdbcConnection();
//
//	 String sql = "CREATE TABLE identityiq.employee(" 
//	                             + "EmpNumber INT not NULL, "
//								 + " EmpName VARCHAR(255), " 
//								 + " EmpSalary VARCHAR(255)" +")"; 
//	 boolean creationstatus = jdbcconnection.createStatement().execute(sql); 
//     if(creationstatus) {
//    
//    	log.error("Table has been Created Successfully" + creationstatus);
//     } else {
//    	 log.error("Table has already Exits in database" + creationstatus);
//     }
//     
//     
//     
//    
//
//SailPointContext context = null;
//	List list = context.getObjects(GroupDefinition.class);
//	list.size();
//
//	  Filter IdentityFilter = Filter.eq("workgroup",false);
//	  QueryOptions identityqo = new QueryOptions();
//	  identityqo.addFilter(IdentityFilter);
//	  int id = context.countObjects(Identity.class,identityqo);
//	  //TaskDefinition td=new TaskDefinition();
//	  //td.setName(name);
//	  TaskDefinition td= context.getObjectByName(TaskDefinition.class, "Refresh Identity Cube");
//	 TaskManager tm=new TaskManager();
//	 tm.run(td,null);
//	 //context.saveObject(tm);
//	 context.commitTransaction();
//	  return ;
	
	
//	Identity id = new Identity();
//	Date d = new Date();
//	  id.setName("Madanapalli");
//	  id.setFirstname("Nalgonda");
//	  id.setLastname("Chittoor");
//	  id.setPassword("Ganesh@1998");
//	  id.setPasswordExpiration(d);
//
//	  
//	  context.saveObject(id);
//	  context.commitTransaction();
//	  
	  
//String fname = object.getAttribute("fname");
//String lname = object.getAttribute("lname");
//HashMap map = new HashMap();
//char f = fname.charAt(0);
//char l = lname.charAt(0);
//
//String fullname = f+""+l;
//String email = fname+""+lname+"@ganesh-it.com";
//if(fullname != null) {
//map.put("Fullname",fullname);
//map.put("Email",email);
//}
//return map;
//	}
	
//	HashSet set = new HashSet();
//	set.add("Ganesh");
//	set.add("manesh");
	//System.out.println(map);
//	Iterator <Entry<Integer,String>> itr = map.entrySet().iterator();
//	
//	while(itr.hasNext()) {
//		System.out.println(itr.next());
//	}
	
//	for(Map.Entry<Integer, String> res : map.entrySet()) {
//		System.out.println(res.getKey() + " " + res.getValue());
//	}
//	System.out.println(map.get(map.size()-1));
//	
//	System.out.println(set);
	
	}
} 

