    package com.sailpoint;



	import sailpoint.object.Workflow;
	import sailpoint.object.Workflow.Approval;
	import sailpoint.object.Identity;
	import java.util.*;
	
	public class Notification {
		public static Object main( String[] args ) {
		   
		
	Object identityName;
	Identity targetUser = context.getObjectByName(Identity.class, identityName);
	Object approvals;
	if ("Nellore".equals(targetUser.getAttribute("location"))) {
	List newApprovals = null;
	Approval[] approvals1;
	if ( approvals1 != null ) {

	
	newApprovals = new ArrayList();
	for ( Approval approval : approvals1 ) {
	if ( approval != null ) {
	// update the approver/owner to the Security Team
	approval.setOwner("Spadmin");
	newApprovals.add(approval);
	}
	}
	}
	
	}
	return approvals;
		}
	}
	