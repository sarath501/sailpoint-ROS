package com.sailpoint;


import java.lang;
import sailpoint.object;
import sailpoint.api;
import sailpoint.connector.Connector;

// import org.apache.commons.collections.*;

// import org.apache.commons.logging.Log;
// import org.apache.commons.logging.LogFactory;

//Logger log = Logger.getLogger(�com.Rule.VHA-ValidateAndArchive�);
//log.info(�����In Customization rule������);
public class Disable {

if(object.getObjectType().compareTo(Connector.TYPE_ACCOUNT) == 0){
//Status here should be replaced with your status field
Object empStatus = object.get(�STATUS�);
if(empStatus.equalsIgnoreCase(�status field of your application �)){
log.info(�The status code is inactive! disable iiq link�);
object.put(�IIQDisabled�, �true�);
}
else{
object.put(�IIQDisabled�, �false�);
}
}



	

}
