package com.sailpoint;

import sailpoint.object.Identity;

public class context {

	public static Identity getObjectByName(Class<Identity> class1, Object identityName) {
		// TODO Auto-generated method stub
		return null;
	}

}
