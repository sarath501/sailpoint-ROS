package com.sailpoint;
import sailpoint.api.SailPointContext;
import java.io.*;  
import java.sql.*; 
import java.io.Reader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import sailpoint.object.AuditEvent;
import sailpoint.object.Filter;
import sailpoint.api.SailPointFactory;
//import sailpoint.connector.ExpiredPasswordException;
import sailpoint.object.Identity;
import sailpoint.object.IdentityAttributeFilterControl;
import sailpoint.object.IdentitySelector;
import sailpoint.object.IdentityTrigger;
import sailpoint.object.QueryOptions;
import sailpoint.object.Rule;
import sailpoint.spring.SpringStarter;
import sailpoint.tools.GeneralException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import org.apache.log4j.Logger;
import java.util.*;

import com.mysql.cj.jdbc.Clob;

public class Provisional {
	 public static SailPointContext context;
	 public static void main(String[] args) throws GeneralException {
	// NID check.....	
	String nid="emp01";
	String name="Bear.Hilton";
	boolean provisioning=true;
	
	 SpringStarter starter = new SpringStarter("iiqBeans"); 
	 starter.start();
	  SailPointContext context = SailPointFactory.createContext();
	  QueryOptions queryOption = new QueryOptions();
	  queryOption.addFilter(Filter.eq("inactive",false));
	  Iterator identityIterator = context.search(Identity.class, queryOption);  
    
	  System.out.println("identityIterator : " + identityIterator);
	  while ( identityIterator.hasNext() ) { 	
	      Identity id = (Identity) identityIterator.next(); 
	      if(nid.equals(id.getAttribute("empId")) || name.equals(id.getDisplayName())){
	    	  provisioning=false;
	    	 // name=id.getDisplayableName();s
	    	  System.out.println("plan fail " );
	      }
	      
	  }
	  starter.close();
// get into the plan.....	  
	  if(provisioning){
		  
		  provisioningPlan();
		  
		  
	  }
	    

}
	private static void provisioningPlan() throws GeneralException {
		// TODO Auto-generated method stub
		
		System.out.println("plan running.... " );
		//
	//	String identityName="sarath";
		
		Logger  mylogger = Logger.getLogger("ihg.idm.TRAKK");
      //  Identity identity = context.getObjectByName(Identity.class, identityName);
        Statement stmt = null;
        Connection connection=null;
       // String usersamaccnumber=(String) identity.getAttribute("networkid");
       // String useremail=(String) identity.getAttribute("email");
// db creat identity.......
int result;

        try {
        	Class.forName("com.mysql.jdbc.Driver");
      
        	String url = "jdbc:mysql://localhost/trakk";
        	java.sql.Connection conn = DriverManager.getConnection(url,"root","root");
        	 stmt = conn.createStatement(); 
           String sql=("INSERT INTO users " + 
                "VALUES ('emp1', 'jsarath.avala', 'jsarath', 'venkat', 'javala8026@gmail.com')"); 
           
           result=stmt.executeUpdate(sql);
            conn.close(); 
            
        mylogger.warn(" Inside TRAKK Update Staging Table ::: "+"Insert Completed");
        } catch (ClassNotFoundException e) {
        mylogger.error(e.getMessage());
        } catch (SQLException e) {
       mylogger.error(e.getMessage());
        } finally{
        if (stmt != null) {
        try {
        stmt.close();
        } catch (Exception e) {
        mylogger.error(e.getMessage());
        }
        }
        }
		
	}
}