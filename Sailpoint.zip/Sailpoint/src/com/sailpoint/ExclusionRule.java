package com.sailpoint;

import sailpoint.object.Identity;
public class ExclusionRule{
	
public static void main(String args[]) {
System.out.println("Entering Exclusion Rule.");
   
        Identity identity;
	Object items;
	Object itemsToExclude;
	// if the identity is inactive, then add all of the items to the
        // exclude list 
    if ( identity.isInactive()) {
      System.out.println("Identity is Inactive : " + identity.getDisplayName());
      System.out.println("Do not certify.");
      ((Object) itemsToExclude).addAll(items);
      ((Object) items).clear(); 
      return "Item excluded because the user is inactive."; 
} 
    else if (identity.getAttribute("firstname").equals("Avala")) {
      System.out.println("Identity is  a Avala: " + identity.getDisplayName());
      System.out.println("Do not certify.");
      itemsToExclude.addAll(items);
      items.clear();
     // items.remove();
      return "Item excluded because the userFirstName is Avala"; 
    } else {
      System.out.println("Identity is Active and Employee: " + identity.getDisplayName());
      System.out.println("Do the certification.");
     return null;
    }

}
}